<?php
require_once('../../config/connect.php');
require_once('../functions.php');

//updateInvestments();