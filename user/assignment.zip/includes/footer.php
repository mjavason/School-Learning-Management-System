<footer id="footer" class="mt-0">
	
	<div class="footer-copyright footer-copyright-style-2">
		<div class="container py-2">
		<div class="col-lg-2 align-self-center mb-5 mb-lg-0">
				<a href="index">
					<img src="img/logo-default-slim.png" class="img-fluid" alt="Demo SEO" width="100" />
				</a>
			</div>
			<div class="row justify-content-between py-4">
				<div class="col-auto">
					<p>© Copyright 2022. All Rights Reserved.</p>
				</div>
				<div class="col-auto">
					<ul class="footer-social-icons social-icons social-icons-clean social-icons-icon-light ms-3">
						<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f text-2"></i></a></li>
						<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter text-2"></i></a></li>
						<li class="social-icons-linkedin"><a href="http://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fab fa-linkedin-in text-2"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</footer>